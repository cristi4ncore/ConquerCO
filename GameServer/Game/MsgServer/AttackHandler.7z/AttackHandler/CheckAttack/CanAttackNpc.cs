﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DeathWish.Game.MsgServer.AttackHandler.CheckAttack
{
   public class CanAttackNpc
    {
       public static bool Verified(Client.GameClient client, Role.SobNpc attacked
    , Database.MagicType.Magic DBSpell)
       {
           if (attacked.Map == MsgTournaments.MsgFootball.MapID)
               return true;
           if (attacked.HitPoints == 0)
               return false;
           if (attacked.IsStatue)
           {
               if (attacked.HitPoints == 0)
                   return false;
               if (client.Player.PkMode == Role.Flags.PKMode.PK)
                   return true;
               else
                   return false;
           }
           if (attacked.UID == Game.MsgTournaments.MsgSchedules.EliteGuildWar.Furnitures[Role.SobNpc.StaticMesh.Pole].UID)
           {
               if (client.Player.MyGuild == null)
               {
                   client.CreateBoxDialog("Sorry you not have Guild.");
                   return false;
               }
               if (Game.MsgTournaments.MsgSchedules.EliteGuildWar.Furnitures[Role.SobNpc.StaticMesh.Pole].HitPoints == 0)
                   return false;
               if (client.Player.MyGuild.GuildName == Game.MsgTournaments.MsgSchedules.EliteGuildWar.Furnitures[Role.SobNpc.StaticMesh.Pole].Name)
                   return false;
               if (Game.MsgTournaments.MsgSchedules.EliteGuildWar.Proces != MsgTournaments.ProcesType.Alive)
                   return false;
           }
           if (attacked.UID == Game.MsgTournaments.MsgSchedules.FightersPole1.Furnitures[Role.SobNpc.StaticMesh.Pole].UID)
           {
               if (client.Player.MyGuild == null)
               {
                   client.CreateBoxDialog("Sorry you not have Guild.");
                   return false;
               }
               if (Game.MsgTournaments.MsgSchedules.FightersPole1.Furnitures[Role.SobNpc.StaticMesh.Pole].HitPoints == 0)
                   return false;
               if (client.Player.MyGuild.GuildName == Game.MsgTournaments.MsgSchedules.FightersPole1.Furnitures[Role.SobNpc.StaticMesh.Pole].Name)
                   return false;
               if (Game.MsgTournaments.MsgSchedules.FightersPole1.Proces != MsgTournaments.ProcesType.Alive)
                   return false;
           }
           if (attacked.UID == Game.MsgTournaments.MsgSchedules.FightersPole2.Furnitures[Role.SobNpc.StaticMesh.Pole].UID)
           {
               if (client.Player.MyGuild == null)
               {
                   client.CreateBoxDialog("Sorry you not have Guild.");
                   return false;
               }
               if (Game.MsgTournaments.MsgSchedules.FightersPole2.Furnitures[Role.SobNpc.StaticMesh.Pole].HitPoints == 0)
                   return false;
               if (client.Player.MyGuild.GuildName == Game.MsgTournaments.MsgSchedules.FightersPole2.Furnitures[Role.SobNpc.StaticMesh.Pole].Name)
                   return false;
               if (Game.MsgTournaments.MsgSchedules.FightersPole2.Proces != MsgTournaments.ProcesType.Alive)
                   return false;
           }
           if (attacked.UID == Game.MsgTournaments.MsgSchedules.FightersPole3.Furnitures[Role.SobNpc.StaticMesh.Pole].UID)
           {
               if (client.Player.MyGuild == null)
               {
                   client.CreateBoxDialog("Sorry you not have Guild.");
                   return false;
               }
               if (Game.MsgTournaments.MsgSchedules.FightersPole3.Furnitures[Role.SobNpc.StaticMesh.Pole].HitPoints == 0)
                   return false;
               if (client.Player.MyGuild.GuildName == Game.MsgTournaments.MsgSchedules.FightersPole3.Furnitures[Role.SobNpc.StaticMesh.Pole].Name)
                   return false;
               if (Game.MsgTournaments.MsgSchedules.FightersPole3.Proces != MsgTournaments.ProcesType.Alive)
                   return false;
           }
           if (attacked.UID == Game.MsgTournaments.MsgSchedules.FightersPole4.Furnitures[Role.SobNpc.StaticMesh.Pole].UID)
           {
               if (client.Player.MyGuild == null)
               {
                   client.CreateBoxDialog("Sorry you not have Guild.");
                   return false;
               }
               if (Game.MsgTournaments.MsgSchedules.FightersPole4.Furnitures[Role.SobNpc.StaticMesh.Pole].HitPoints == 0)
                   return false;
               if (client.Player.MyGuild.GuildName == Game.MsgTournaments.MsgSchedules.FightersPole4.Furnitures[Role.SobNpc.StaticMesh.Pole].Name)
                   return false;
               if (Game.MsgTournaments.MsgSchedules.FightersPole4.Proces != MsgTournaments.ProcesType.Alive)
                   return false;
           }
           if (attacked.UID == MsgTournaments.MsgArcherClass.Furnitures[Role.SobNpc.StaticMesh.Pole].UID)
           {
               if (MsgTournaments.MsgArcherClass.Furnitures[Role.SobNpc.StaticMesh.Pole].HitPoints == 0)
                   return false;
               if (client.Player.Name == MsgTournaments.MsgArcherClass.Furnitures[Role.SobNpc.StaticMesh.Pole].Name)
                   return false;
               if (MsgTournaments.MsgArcherClass.Proces == MsgTournaments.ProcesType.Dead)//MsgArcherClass
                   return false;
           }
           if (attacked.UID == MsgTournaments.MsgDragonClass.Furnitures[Role.SobNpc.StaticMesh.Pole].UID)
           {
               if (MsgTournaments.MsgDragonClass.Furnitures[Role.SobNpc.StaticMesh.Pole].HitPoints == 0)
                   return false;
               if (client.Player.Name == MsgTournaments.MsgDragonClass.Furnitures[Role.SobNpc.StaticMesh.Pole].Name)
                   return false;
               if (MsgTournaments.MsgDragonClass.Proces == MsgTournaments.ProcesType.Dead)//MsgDragonClass
                   return false;
           }
           if (attacked.UID == MsgTournaments.MsgFireClass.Furnitures[Role.SobNpc.StaticMesh.Pole].UID)
           {
               if (MsgTournaments.MsgFireClass.Furnitures[Role.SobNpc.StaticMesh.Pole].HitPoints == 0)
                   return false;
               if (client.Player.Name == MsgTournaments.MsgFireClass.Furnitures[Role.SobNpc.StaticMesh.Pole].Name)
                   return false;
               if (MsgTournaments.MsgFireClass.Proces == MsgTournaments.ProcesType.Dead)//MsgFireClass
                   return false;
           }
           if (attacked.UID == MsgTournaments.MsgMonkClass.Furnitures[Role.SobNpc.StaticMesh.Pole].UID)
           {
               if (MsgTournaments.MsgMonkClass.Furnitures[Role.SobNpc.StaticMesh.Pole].HitPoints == 0)
                   return false;
               if (client.Player.Name == MsgTournaments.MsgMonkClass.Furnitures[Role.SobNpc.StaticMesh.Pole].Name)
                   return false;
               if (MsgTournaments.MsgMonkClass.Proces == MsgTournaments.ProcesType.Dead)//MsgMonkClass
                   return false;
           }
           if (attacked.UID == MsgTournaments.MsgNinjaClass.Furnitures[Role.SobNpc.StaticMesh.Pole].UID)
           {
               if (MsgTournaments.MsgNinjaClass.Furnitures[Role.SobNpc.StaticMesh.Pole].HitPoints == 0)
                   return false;
               if (client.Player.Name == MsgTournaments.MsgNinjaClass.Furnitures[Role.SobNpc.StaticMesh.Pole].Name)
                   return false;
               if (MsgTournaments.MsgNinjaClass.Proces == MsgTournaments.ProcesType.Dead)//MsgNinjaClass
                   return false;
           }
           if (attacked.UID == MsgTournaments.MsgPirateClass.Furnitures[Role.SobNpc.StaticMesh.Pole].UID)
           {
               if (MsgTournaments.MsgPirateClass.Furnitures[Role.SobNpc.StaticMesh.Pole].HitPoints == 0)
                   return false;
               if (client.Player.Name == MsgTournaments.MsgPirateClass.Furnitures[Role.SobNpc.StaticMesh.Pole].Name)
                   return false;
               if (MsgTournaments.MsgPirateClass.Proces == MsgTournaments.ProcesType.Dead)//MsgPirateClass
                   return false;
           }
           if (attacked.UID == MsgTournaments.MsgTrojanClass.Furnitures[Role.SobNpc.StaticMesh.Pole].UID)
           {
               if (MsgTournaments.MsgTrojanClass.Furnitures[Role.SobNpc.StaticMesh.Pole].HitPoints == 0)
                   return false;
               if (client.Player.Name == MsgTournaments.MsgTrojanClass.Furnitures[Role.SobNpc.StaticMesh.Pole].Name)
                   return false;
               if (MsgTournaments.MsgTrojanClass.Proces == MsgTournaments.ProcesType.Dead)//MsgTrojanClass
                   return false;
           }
           if (attacked.UID == MsgTournaments.MsgWarriorClass.Furnitures[Role.SobNpc.StaticMesh.Pole].UID)
           {
               if (MsgTournaments.MsgWarriorClass.Furnitures[Role.SobNpc.StaticMesh.Pole].HitPoints == 0)
                   return false;
               if (client.Player.Name == MsgTournaments.MsgWarriorClass.Furnitures[Role.SobNpc.StaticMesh.Pole].Name)
                   return false;
               if (MsgTournaments.MsgWarriorClass.Proces == MsgTournaments.ProcesType.Dead)//MsgWarriorClass
                   return false;
           }
           if (attacked.UID == MsgTournaments.MsgWaterClass.Furnitures[Role.SobNpc.StaticMesh.Pole].UID)
           {
               if (MsgTournaments.MsgWaterClass.Furnitures[Role.SobNpc.StaticMesh.Pole].HitPoints == 0)
                   return false;
               if (client.Player.Name == MsgTournaments.MsgWaterClass.Furnitures[Role.SobNpc.StaticMesh.Pole].Name)
                   return false;
               if (MsgTournaments.MsgWaterClass.Proces == MsgTournaments.ProcesType.Dead)//MsgWaterClass
                   return false;
           }
           if (attacked.UID == MsgTournaments.MsgWindClass.Furnitures[Role.SobNpc.StaticMesh.Pole].UID)
           {
               if (MsgTournaments.MsgWindClass.Furnitures[Role.SobNpc.StaticMesh.Pole].HitPoints == 0)
                   return false;
               if (client.Player.Name == MsgTournaments.MsgWindClass.Furnitures[Role.SobNpc.StaticMesh.Pole].Name)
                   return false;
               if (MsgTournaments.MsgWindClass.Proces == MsgTournaments.ProcesType.Dead)//MsgWindClass
                   return false;
           }
           if (attacked.UID == MsgTournaments.MsgEmperorWar.Furnitures[Role.SobNpc.StaticMesh.Pole].UID)
           {
               if (MsgTournaments.MsgEmperorWar.Furnitures[Role.SobNpc.StaticMesh.Pole].HitPoints == 0)
                   return false;
               if (client.Player.Name == MsgTournaments.MsgEmperorWar.Furnitures[Role.SobNpc.StaticMesh.Pole].Name)
                   return false;
               if (MsgTournaments.MsgEmperorWar.Proces == MsgTournaments.ProcesType.Dead)
                   return false;
           }
           if (attacked.UID == MsgTournaments.MsgGuildPole.Furnitures[Role.SobNpc.StaticMesh.Pole].UID)
           {

               if (MsgTournaments.MsgGuildPole.Furnitures[Role.SobNpc.StaticMesh.Pole].HitPoints == 0)
                   return false;
               if (client.Player.Name == MsgTournaments.MsgGuildPole.Furnitures[Role.SobNpc.StaticMesh.Pole].Name)
                   return false;
               if (MsgTournaments.MsgGuildPole.Proces == MsgTournaments.ProcesType.Dead)//MsgNobilityPole
                   return false;
           }
           if (attacked.UID == MsgTournaments.MsgNobilityPole.Furnitures[Role.SobNpc.StaticMesh.Pole].UID)
           {
               if (MsgTournaments.MsgNobilityPole.Furnitures[Role.SobNpc.StaticMesh.Pole].HitPoints == 0)
                   return false;
               if (client.Player.Name == MsgTournaments.MsgNobilityPole.Furnitures[Role.SobNpc.StaticMesh.Pole].Name)
                   return false;
               if (MsgTournaments.MsgNobilityPole.Proces == MsgTournaments.ProcesType.Dead)//MsgNobilityPole
                   return false;
           }
           if (attacked.UID == MsgTournaments.MsgNobilityPole1.Furnitures[Role.SobNpc.StaticMesh.Pole].UID)
           {
               if (MsgTournaments.MsgNobilityPole1.Furnitures[Role.SobNpc.StaticMesh.Pole].HitPoints == 0)
                   return false;
               if (client.Player.Name == MsgTournaments.MsgNobilityPole1.Furnitures[Role.SobNpc.StaticMesh.Pole].Name)
                   return false;
               if (MsgTournaments.MsgNobilityPole1.Proces == MsgTournaments.ProcesType.Dead)//MsgNobilityPole
                   return false;
           }
           if (attacked.UID == MsgTournaments.MsgNobilityPole2.Furnitures[Role.SobNpc.StaticMesh.Pole].UID)
           {
               if (MsgTournaments.MsgNobilityPole2.Furnitures[Role.SobNpc.StaticMesh.Pole].HitPoints == 0)
                   return false;
               if (client.Player.Name == MsgTournaments.MsgNobilityPole2.Furnitures[Role.SobNpc.StaticMesh.Pole].Name)
                   return false;
               if (MsgTournaments.MsgNobilityPole2.Proces == MsgTournaments.ProcesType.Dead)//MsgNobilityPole
                   return false;
           }
           if (attacked.UID == MsgTournaments.MsgNobilityPole3.Furnitures[Role.SobNpc.StaticMesh.Pole].UID)
           {
               if (MsgTournaments.MsgNobilityPole3.Furnitures[Role.SobNpc.StaticMesh.Pole].HitPoints == 0)
                   return false;
               if (client.Player.Name == MsgTournaments.MsgNobilityPole3.Furnitures[Role.SobNpc.StaticMesh.Pole].Name)
                   return false;
               if (MsgTournaments.MsgNobilityPole3.Proces == MsgTournaments.ProcesType.Dead)//MsgNobilityPole
                   return false;
           }
           if (attacked.UID == MsgTournaments.MsgGuildPole1.Furnitures[Role.SobNpc.StaticMesh.Pole].UID)
           {
               if (MsgTournaments.MsgGuildPole1.Furnitures[Role.SobNpc.StaticMesh.Pole].HitPoints == 0)
                   return false;
               if (client.Player.Name == MsgTournaments.MsgGuildPole1.Furnitures[Role.SobNpc.StaticMesh.Pole].Name)
                   return false;
               if (MsgTournaments.MsgGuildPole1.Proces == MsgTournaments.ProcesType.Dead)//MsgGuildPole
                   return false;
           }
           if (attacked.UID == MsgTournaments.MsgGuildPole2.Furnitures[Role.SobNpc.StaticMesh.Pole].UID)
           {
               if (MsgTournaments.MsgGuildPole2.Furnitures[Role.SobNpc.StaticMesh.Pole].HitPoints == 0)
                   return false;
               if (client.Player.Name == MsgTournaments.MsgGuildPole2.Furnitures[Role.SobNpc.StaticMesh.Pole].Name)
                   return false;
               if (MsgTournaments.MsgGuildPole2.Proces == MsgTournaments.ProcesType.Dead)//MsgGuildPole
                   return false;
           }
           if (attacked.UID == MsgTournaments.MsgVeteransWar.Furnitures[Role.SobNpc.StaticMesh.Pole].UID)
           {
               if (MsgTournaments.MsgVeteransWar.Furnitures[Role.SobNpc.StaticMesh.Pole].HitPoints == 0)
                   return false;
               if (client.Player.Name == MsgTournaments.MsgVeteransWar.Furnitures[Role.SobNpc.StaticMesh.Pole].Name)
                   return false;
               if (MsgTournaments.MsgVeteransWar.Proces == MsgTournaments.ProcesType.Dead)//War_of_the_players
                   return false;
           }
           if (attacked.UID == MsgTournaments.MsgWarOfPlayers.Furnitures[Role.SobNpc.StaticMesh.Pole].UID)
           {
               if (MsgTournaments.MsgWarOfPlayers.Furnitures[Role.SobNpc.StaticMesh.Pole].HitPoints == 0)
                   return false;
               if (client.Player.Name == MsgTournaments.MsgWarOfPlayers.Furnitures[Role.SobNpc.StaticMesh.Pole].Name)
                   return false;
               if (MsgTournaments.MsgWarOfPlayers.Proces == MsgTournaments.ProcesType.Dead)//War_of_the_players
                   return false;
           }
           if (attacked.UID == Game.MsgTournaments.MsgSchedules.GuildWar.Furnitures[Role.SobNpc.StaticMesh.Pole].UID)
           {
               if (client.Player.MyGuild == null)
               {
                   client.CreateBoxDialog("Sorry you not have Guild.");
                   return false;
               }
               if (Game.MsgTournaments.MsgSchedules.GuildWar.Furnitures[Role.SobNpc.StaticMesh.Pole].HitPoints == 0)
                   return false;
               if (client.Player.GuildID == Game.MsgTournaments.MsgSchedules.GuildWar.Winner.GuildID)
                   return false;
               if (Game.MsgTournaments.MsgSchedules.GuildWar.Proces == MsgTournaments.ProcesType.Dead || Game.MsgTournaments.MsgSchedules.GuildWar.Proces == MsgTournaments.ProcesType.Idle)
                   return false;
           }
           if (attacked.UID == Game.MsgTournaments.MsgSchedules.SuperGuildWar.Furnitures[MsgTournaments.MsgSuperGuildWar.FurnituresType.Pole].UID)
           {
               if (client.Player.MyGuild == null)
               {
                   client.CreateBoxDialog("Sorry you not have Guild.");
                   return false;
               }
               if (Game.MsgTournaments.MsgSchedules.SuperGuildWar.Furnitures[MsgTournaments.MsgSuperGuildWar.FurnituresType.Pole].HitPoints == 0)
                   return false;
               if (client.Player.GuildID == Game.MsgTournaments.MsgSchedules.SuperGuildWar.Winner.GuildID)
                   return false;
               if (Game.MsgTournaments.MsgSchedules.SuperGuildWar.Proces == MsgTournaments.ProcesType.Dead || Game.MsgTournaments.MsgSchedules.SuperGuildWar.Proces == MsgTournaments.ProcesType.Idle)
                   return false;
           }

           MsgTournaments.MsgCaptureTheFlag.Basse Bas;
           if (MsgTournaments.MsgSchedules.CaptureTheFlag.Bases.TryGetValue(attacked.UID, out Bas))
           {
               if (MsgTournaments.MsgSchedules.CaptureTheFlag.Proces != MsgTournaments.ProcesType.Alive)
                   return false;
               if (client.Player.MyGuild == null)
                   return false;
               if (Bas.Npc.HitPoints == 0)
                   return false;
               if (Bas.CapturerID == client.Player.GuildID)
                   return false;

           }
           return true;
       }
    }
}
